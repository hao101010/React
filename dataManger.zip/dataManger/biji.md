web 

1. 端 移动端(RN flutter hybrid  OC  c++)  小程序  web端  iot  大屏

2. 前后端 node

3. 工程化 脚手架  

4. 图形学  AI+图形   数据 ==>数据驱动图形 
    WEB JS 数据

5. 前端多媒体 音视频 

6. 引擎


数据状态管理 

1. redux 实现
2. redux中间件 
3. redux-saga （js协程） 生成器

4. 生成器在浏览器中的实现  协程（react、vue）、进程、线程

5. async 

6. mobx4  mobx5（vue3）

7.并发 、并行 webworker  数据状态

8. dva（redux、redux-saga） mobx==>dva






MVC
MVP
MVVM (vue 、react、omi)



```html
<div>
<span id='container'>0</span>
<div id='btn'>+</div>
</div>
MVP   presenter

<script>

const cofig={
    container:'',
    btn:''
}

function add(num){
    return  num+1
}


container=docurmnt.getBy;
btn=docurmnt.getBy;


btn.addEventListener('click',()=>{
    const curr=container.innertext

    const newValue=add(curr)
    container.innertext=newValue;
})
</script>
```
react  vue（自己）


react视图层   ==不清楚 哪个数==》dom

react15  批量更行

react16 fiber==>可以中断   (协程)


react17 启发式算法

diff整个页面  数据是独立 



运行时 

jsx  ==>js 灵活
<div></div>==>React.createElement


react 运行时 

function A() {
    return React.createElement("div", null, "123");
}

运行时dom diff  fiber ==> 




vue   eventBus
编译时 
 Ateamplate{}  Vue text 
 模板 .vue dom diff 

vue3
 模板编译 
 数据监听 



数据驱动

数据管理 
1.数据存储 、修改 
    思想  flux 
redux  react 




48
MVC 

redux 中间件   其他的一些 协程 


reducer 
state 

中间件 
node koa express  
vue 
react


dispatch  ==>扩展dispatch 独立扩展
//发送aciton 请求 ，数据回来之后 

异步中间件 ==> 请求 



给与开发者 有扩展原本功能的接口


redux 怎么去实现中间件的一个架构 


1.生成器原理（redux 中间 ）
2.redux mobx vuex(vue)
3.数据管理多线程方法



redux 发出指令  ==》对象

store.dispatch({type:'fetchDispacth'})


redux-saga;

function fetchDispacth(){
    fetch()=>{}
}



redux-promise
redux-thunk



addEventLisenter()




take 
put 


channel()==>事件源的抽象 
1. 事件出发的源头 屏蔽了 
2. 只关心事件触发时要处理的事情 

take  ==>那个action 要做什么情况 


takeEvery




dispatch  ==> put(action)==>fn();


function channel() {
    let taker;
    function take(cb){
        taker=cb
    }

    function put(input){
        if(taker){
            const tempTaker=taker;
            taker=null;
            tempTaker();
        }
    }
}





//generator 内部是怎么实现的 

function *a(){

        yield 1;
        console.log(2);
        yeild 3
}

var  b=a();

console.log('开始')
b.next()
console.log('第一次')
1. 协程   ==》react实现协程的思想 
2. 异步控制


操作系统 


进程   线程    协程 


a ==> 

b

a+b 
b+a



冻结函数作用域 

var a=0;
async function test(){
    let result=a+await 10;
    console.log(result);
}
test();
a=a+1;


var a=0;
async function test(){
    let result=await 10+a;
    console.log(result);
}
test();
a=a+1;


已经有原型链的和原型对象的够着函数 {next:(),return:()}
var marked=regeneratorRuntime.mark(生成器)；根据w3c 构建生成器以及迭代器的原型链关系网,

 1. Gp={};
 2. defineIteratorMethods(Gp);
      function defineIteratorMethods(prototype) {
        ["next", "throw", "return"].forEach(function (method) {
            prototype[method] = function (arg) {
                return this._invoke(method, arg);
            };
        });
    }
regeneratorRuntime.wrap  ==>返回迭代器 (业务代码逻辑打包的, marked)


mobx redux  vue3


五个月   
录播课  ==> 录播课
直播课  

2.内推 





