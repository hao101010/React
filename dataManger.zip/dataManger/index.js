var _marked =
    /*#__PURE__*/
    regeneratorRuntime.mark(hello);


/**
function *hello(a){
    yield 'hello'
    yield 'world'
    return 'end'
}
 */

/**
 * 
 * var _context={
 *     next:4,//
 *     prev:2，
 *     abrupt()=>{
 *     
 *     }
 * }
 */
//_context 内部 状态 ==>generator 管理内部运行的状态
function hello(a) {
    return regeneratorRuntime.wrap(function hello$(_context) {
        while (1) {
            // _context.next=0，_context.next=0
            switch (_context.prev = _context.next) {
                case 0:
                    _context.next = 2;
                    return 'hello';

                case 2:
                    _context.next = 4;
                    return 'world';

                case 4:
                    return _context.abrupt("return", 'end');

                case 5:
                case "end":
                    return _context.stop();
            }
        }
    }, _marked);
}